<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Campanha Novembro Azul</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #e8f4ff;
            text-align: center;
            padding: 30px;
        }
        h1 {
            color: #004b87;
            text-transform: uppercase;
        }
        form {
            background-color: white;
            border-radius: 10px;
            padding: 20px;
            width: 320px;
            margin: 0 auto;
            box-shadow: 0 0 8px rgba(0,0,0,0.2);
        }
        label {
            font-weight: bold;
            display: block;
            margin-top: 10px;
        }
        input {
            width: 90%;
            padding: 8px;
            border-radius: 6px;
            border: 1px solid #ccc;
            margin-bottom: 10px;
        }
        button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 6px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        p {
            font-weight: bold;
        }
    </style>
</head>
<body>
    <h1>Campanha Novembro Azul</h1>
    
    <div id="cadastro">
        
        <form action="azulzinho.php" method="POST">
            <label>Nome: </label><br>
            <input type="text" name="nome" required><br>
            <label>Idade: </label><br>
            <input type="number" name="idade" required><br>
            <label>CPF: </label><br>
            <input type="text" name="cpf" minlength="11" maxlength="11" placeholder="Com 11 dígitos" required><br>    
            <label>Data da Consulta: </label><br>
            <input type="date" name="dataConsulta" required><br>
            <button type="submit" name="cadastrar">Enviar</button>

        </form>

    </div>
<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
     $nome = $_POST["nome"];
     $idade = $_POST["idade"];
     $cpf = $_POST["cpf"];

    if(!ctype_digit($cpf) || strlen($cpf) != 11) {
        echo "<p>O cpf deve conter exatamente 11 números.</p>";
        exit;

    }
    $dataConsulta = $_POST["dataConsulta"];
    $conn = new mysqli("localhost","root","aluno","chuva","3307");

            if ($conn->connect_error) {
                   die("<p>Erro na conexão: " . $conn->connect_error . "</p>");
               }

        if (isset($_POST["cadastrar"])){
            $sql = "INSERT INTO lua (cpf) VALUES ('$cpf')";
            
            if ($conn->query($sql) === TRUE) {
                echo "<p> CPF cadastrado com sucesso!</p>";
                
            } else {
                echo "<p> CPF ja cadastrado.</p>";
            }
        }


            $sql = "SELECT * FROM lua WHERE cpf = '$cpf'";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                session_start();
                $_SESSION["cpf"] = $cpf;
                header("Location: azul.php");
                exit;
            } else {
                echo "<p style='color:red;'>CPF não encontrado. Faça o cadastro primeiro.</p>";
            }

        
        $conn->close();
    }


?>
 


</body>
</html>