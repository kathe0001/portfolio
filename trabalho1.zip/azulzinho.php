<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Campanha Novembro Azul</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #e8f4ff;
            text-align: center;
            padding: 30px;
        }
        h1 {
            color: #004b87;
            text-transform: uppercase;
        }
        form {
            background-color: white;
            border-radius: 10px;
            padding: 20px;
            width: 320px;
            margin: 0 auto;
            box-shadow: 0 0 8px rgba(0,0,0,0.2);
        }
        label {
            font-weight: bold;
            display: block;
            margin-top: 10px;
        }
        input {
            width: 90%;
            padding: 8px;
            border-radius: 6px;
            border: 1px solid #ccc;
            margin-bottom: 10px;
        }
        button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 6px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        p {
            font-weight: bold;
        }
    </style>
</head>
<body>

    <div id="container">
    <h2>Bem vindo ao novembro azul!</h2>
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST["nome"];
    $idade = $_POST["idade"];
    $cpf= $_POST["cpf"];
    $dataConsulta = $_POST["dataConsulta"];

    echo "<h3>Dados recebidos (POST)</h3>";
    echo "Nome:  $nome<br>";
    echo "Idade:  $idade<br>";
    echo "CPF:  $cpf<br>";
    echo "Data da consulta:  $dataConsulta<br>";
}
    ?>
    <p>Olá o seu cpf foi cadastrado com sucesso</p>
    <h3>Inforções sobre o câncer de prostata</h3>
    <p>O câncer de próstata é um tumor maligno que afeta a glândula prostática e é o segundo tipo de câncer mais 
         entre os homens no Brasil, ficando atrás apenas do câncer de pele. Ele geralmente cresce lentamente e não
          apresenta sintomas nas fases iniciais, mas pode causar problemas urinários, dores ósseas e outros sintomas 
          em estágios avançados. O diagnóstico é feito com base na suspeita médica, que pode levar à realização de 
          exames como o toque retal e o PSA, seguidos de biópsia para confirmação. Os principais fatores de risco 
          incluem a idade (risco aumenta após os 55 anos) e histórico familiar.</p><br>
    <p>Tratamento Depende do estágio: O tratamento varia conforme a agressividade e o avanço da doença.
Opções comuns: Vigilância ativa, cirurgia para remover a próstata, radioterapia e terapia hormonal.
Terapia hormonal: Usada principalmente para controlar tumores avançados que se espalharam, 
diminuindo os níveis de testosterona.</p><br>
<p>Procure um medico!</p>

<a href="azul.php">Sair</a>
    



    
</body>
</html>